---
layout: default
title: About
permalink: /index.html
---
# Welcome to the Plain Webcomic Live Demo!

<<<<<<< HEAD
This is a basic webcomic theme that you can use with Jekyll, a static site generator.

Here's the guide for building your own free webcomic page using this theme and Github Pages.

<a href="https://github.com/peahatlanding/Plain-Webcomic/docs/index.html" class="btn btn-primary" role="button" aria-disabled="true">Startup Guide</a>

Here's a guide for beginners on how to modify your site and upload pages.

<a href="https://github.com/peahatlanding/Plain-Webcomic/docs/howto.html" class="btn btn-primary" role="button" aria-disabled="true">UserGuide</a>
=======
>>>>>>> 9322bea2bb2fd543b42d0025942ad29a2a55c935
