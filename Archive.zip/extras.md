---
layout: default
title: About
permalink: /extras
---
# Extras

This might be a nice place to put some of your concept art.

## Comic Resources
This website was made using [the Bootstrap framework](http://getbootstrap.com/) and [Jekyll](https://jekyllrb.com/), a static site generator. You can download the comic website code [here](https://github.com/peahatlanding/Webcomic-Jekyll-Theme).

Thank you!
